class CfgPatches
{
	class squadFSM
	{
		
		name 				= "Squad FSM";
		author 				= "YipMan, Tally";
		requiredVersion 	= 2;
		requiredAddons[] 	= { "A3_Functions_F" };
		units[] 			= {};
		weapons[] 			= {};
	};
};