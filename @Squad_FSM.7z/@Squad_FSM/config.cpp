class CfgPatches
{
	class soldierFSM
	{
		
		name 				= "soldier FSM v0.29";
		author 				= "YipMan, Jihem, Deebs, Tally";
		requiredVersion 	= 1.60;
		requiredAddons[] 	= { "A3_Functions_F" };
		units[] 			= {};
		weapons[] 			= {};
	};
};