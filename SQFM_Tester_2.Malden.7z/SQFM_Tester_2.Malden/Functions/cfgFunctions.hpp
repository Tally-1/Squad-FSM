class CfgFunctions
{
	class Talib
	{
		class misc
		{
			
		};
		class init
		{
			class preInitOverWrite {preInit = 1;};
		};
	};
};